#include "ros/ros.h"  //ROS系统中最常见的公共部分所需的全部头文件。
#include "std_msgs/String.h" //它引用了位于std_msgs包里的std_msgs/String消息。

#include <sstream>

/**
 * This tutorial demonstrates simple sending of messages over the ROS system.
 */
int main(int argc, char **argv)
{
  /**
     初始化ROS。这使得ROS可以通过命令行进行名称重映射——不过目前不重要。
    这也是我们给节点指定名称的地方。节点名在运行的系统中必须是唯一的。
    注意：名称必须是基本名称，例如不能包含任何斜杠
   */
  ros::init(argc, argv, "talker");

  /**
    为这个进程的节点创建句柄。创建的第一个
    NodeHandle实际上将执行节点的初始化，而最后一个被销毁的
    NodeHandle将清除节点所使用的任何资源。
   */
  ros::NodeHandle n;

  //以最简方式发布（创建）一个话题。
  ros::Publisher chatter_pub = n.advertise<std_msgs::String>("chatter", 1000);


  //ros::Rate对象能让你指定循环的频率。它会记录从上次调用
  //Rate::sleep()到现在已经有多长时间，并休眠正确的时间。在本例中，我们告诉它希望以10Hz运行。
  ros::Rate loop_rate(10);

  /**
  ros::ok()在以下情况会返回false：
    收到SIGINT信号（Ctrl+C）
    被另一个同名的节点踢出了网络
        ros::shutdown()
    被程序的另一部分调用
    所有的
        ros::NodeHandles都已被销毁
    一旦ros::ok()返回false, 所有的ROS调用都会失败。
   */
  int count = 0;
  while (ros::ok())
  {
    /**
     * This is a message object. You stuff it with data, and then publish it.
     */
    std_msgs::String msg; // 声明一个ROS标准字符串类型的消息对象

    std::stringstream ss; // 创建一个字符串流对象，用于高效拼接字符串
    ss << "hello world " << count; // 将"hello world "和count变量的值拼接到字符串流
    msg.data = ss.str();  // 将字符串流内容转为std::string并赋值给消息的数据域

    ROS_INFO("%s", msg.data.c_str());

 
    chatter_pub.publish(msg); //现在，我们实际上把这个信息广播给了任何已连接的节点。

    //此处调用ros::spinOnce()对于这个简单程序来说没啥必要，因为我们没有接收任何回调。然而，如果要在这个程序中添加订阅，但此处没有
    //ros::spinOnce()的话，回调函数将永远不会被调用。所以还是加上吧。
    ros::spinOnce();

    //现在我们使用
    //ros::Rate在剩下的时间内睡眠，以让我们达到10Hz的发布速率。
    loop_rate.sleep();
    ++count;
  }


  return 0;
}