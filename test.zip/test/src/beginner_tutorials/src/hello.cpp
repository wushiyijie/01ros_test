#include "ros/ros.h"                    //使用ros系统的头文件

 
int main(int argc, char *argv[])
{
    //执行 ros 节点初始化
    ros::init(argc,argv,"hello");      
     
    //创建 ros 节点句柄(非必须)
    ros::NodeHandle n;
    
    //控制台输出 hello world
    ROS_INFO("hello world!");        //类似printf，ROS_INFO以日志的形式输出( 带发生时间)

    return 0;
}